import java.util.ArrayList;
import java.util.List;

class Shape {
    private ArrayList<Point> points;

    public Shape() {
        points = new ArrayList<Point>();
    }

    public void addPoint(Point point) {
        points.add(point);
    }

    public ArrayList<Point> getPoints() {
        return points;
    }

    public double calculatePerimeter() {
        int numSides = points.size();
        double perimeter = 0;
        for (int i = 0; i < numSides; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get((i + 1) % numSides);
            perimeter += p1.distance(p2);
        }
        return perimeter;
    }

    public double getLongestSide() {
        int numSides = points.size();
        double longestSide = 0;
        for (int i = 0; i < numSides; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get((i + 1) % numSides);
            double sideLength = p1.distance(p2);
            if (sideLength > longestSide) {
                longestSide = sideLength;
            }
        }
        return longestSide;
    }

    public double getAverageSideLength() {
        int numSides = points.size();
        double totalLength = 0;
        for (int i = 0; i < numSides; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get((i + 1) % numSides);
            totalLength += p1.distance(p2);
        }
        return totalLength;
    }
}