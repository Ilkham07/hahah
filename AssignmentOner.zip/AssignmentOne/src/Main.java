import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.InputMismatchException;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.InputMismatchException;

class AssignmentOne {
    public static void main(String[] args) {
        Shape shape = new Shape();
        try {
            Scanner sc1 = new Scanner(new File("C://Users/toleg//Desktop/file1.txt/"));
            Scanner sc2 = new Scanner(new File("C://Users/toleg//Desktop/file2.txt/"));
            int x, y;
            while (sc1.hasNextLine()) {
                String line = sc1.nextLine();
                try {
                    String[] values = line.split(",");
                    x = Integer.parseInt(values[0]);
                    y = Integer.parseInt(values[1]);
                    Point point = new Point(x, y);
                    shape.addPoint(point);
                } catch (InputMismatchException e) {
                    System.out.println("Error: Invalid point format: " + line);
                } catch (NumberFormatException e) {
                    System.out.println("Error: Invalid point format: " + line);
                }
            }
            while (sc2.hasNextLine()) {
                String line = sc2.nextLine();
                try {
                    String[] values = line.split(",");
                    x = Integer.parseInt(values[0]);
                    y = Integer.parseInt(values[1]);
                    Point point = new Point(x, y);
                    shape.addPoint(point);
                } catch (InputMismatchException e) {
                    System.out.println("Error: Invalid point format: " + line);
                } catch (NumberFormatException e) {
                    System.out.println("Error: Invalid point format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Output data using Shape class functions
        System.out.println("Shape perimeter: " + shape.calculatePerimeter());
        System.out.println("Longest side: " + shape.getLongestSide());
        System.out.println("Average side length: " + shape.getAverageSideLength());
    }
}